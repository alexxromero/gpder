from . import gaussian_process
from . import kernels

from .gaussian_process import GaussianProcessRegressor
